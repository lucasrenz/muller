import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Briefcase, Sparkles, CircleDot } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const VagasPage = () => {
  const navigate = useNavigate();

  return (
    <>
      <Helmet>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,200..800&display=swap"
          rel="stylesheet"
        />
      </Helmet>

      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.9, ease: 'easeOut' }}
        className="min-h-screen relative overflow-hidden bg-gradient-to-br from-slate-50 via-white to-slate-100 px-4 py-20"
        style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}
      >
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -left-24 top-10 h-72 w-72 rounded-full bg-[#f9b28c]/20 blur-3xl" />
          <div className="absolute right-0 top-24 h-72 w-72 rounded-full bg-[#8eb6ff]/20 blur-3xl" />
          <div className="absolute left-1/2 top-72 h-56 w-56 -translate-x-1/2 rounded-full bg-[#f7d5e1]/20 blur-3xl" />
          <div className="absolute -right-20 bottom-10 h-48 w-48 rounded-full bg-[#ff7b5c]/15 blur-3xl" />

          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
            className="absolute left-10 top-1/3 h-40 w-40 rounded-full border border-slate-200/40"
          />

          <motion.div
            animate={{ y: [0, 14, 0] }}
            transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute right-16 top-1/4 h-6 w-6 rounded-full bg-brand-500/20"
          />

          <motion.div
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute left-16 bottom-28 h-5 w-5 rounded-full bg-[#ff9b88]/30"
          />
        </div>

        <div className="relative mx-auto flex w-full max-w-5xl flex-col items-center text-center gap-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="relative w-full rounded-[40px] border border-slate-200/60 bg-white/90 px-6 py-10 shadow-2xl shadow-slate-300/20 backdrop-blur-2xl sm:px-10 sm:py-14"
          >
            <div className="absolute inset-x-12 top-0 h-24 bg-gradient-to-r from-brand-500/20 via-transparent to-slate-200/30 blur-3xl" />
            <div className="absolute left-6 top-10 h-16 w-16 rounded-full bg-brand-500/10 blur-2xl" />
            <div className="absolute right-6 top-16 h-14 w-14 rounded-full bg-[#f59e7c]/15 blur-2xl" />

            <div className="relative flex flex-col items-center gap-6">
              <motion.span
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.6, ease: 'easeOut' }}
                className="inline-flex items-center gap-2 rounded-full border border-slate-200/80 bg-slate-50/80 px-4 py-2 text-sm font-semibold uppercase tracking-[0.18em] text-slate-700 shadow-sm"
              >
                <Sparkles className="h-4 w-4 text-brand-600" />
                Em breve
              </motion.span>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.7, ease: 'easeOut' }}
                className="flex h-20 w-20 items-center justify-center rounded-[28px] bg-gradient-to-br from-brand-500/15 to-brand-500/5 text-brand-600 shadow-lg shadow-brand-500/10"
              >
                <Briefcase className="h-10 w-10" />
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35, duration: 0.75, ease: 'easeOut' }}
                className="text-5xl sm:text-6xl font-black tracking-[-0.05em] text-slate-950 leading-tight"
              >
                Ainda estamos construindo essa página
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.45, duration: 0.75, ease: 'easeOut' }}
                className="max-w-2xl text-lg leading-8 text-slate-600 sm:text-xl"
              >
                Retorne em breve para conferir as oportunidades e novidades que estamos preparando para você.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.55, duration: 0.7, ease: 'easeOut' }}
                whileHover={{ scale: 1.02 }}
                className="mt-6"
              >
                <button
                  onClick={() => navigate('/')}
                  className="inline-flex items-center justify-center rounded-3xl bg-gradient-to-r from-brand-600 to-brand-500 px-8 py-3.5 text-base font-semibold text-white shadow-2xl shadow-brand-500/25 transition-all duration-300 hover:shadow-brand-500/40"
                >
                  Voltar para o início
                </button>
              </motion.div>
            </div>
          </motion.div>

          <div className="grid w-full grid-cols-1 gap-4 md:grid-cols-3">
            <div className="rounded-3xl border border-slate-200/70 bg-white/80 p-5 text-left shadow-lg shadow-slate-200/10 backdrop-blur-xl">
              <div className="flex items-center gap-3 text-slate-700">
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-brand-500/10 text-brand-600">
                  <CircleDot className="h-5 w-5" />
                </span>
                <span className="text-sm font-semibold uppercase tracking-[0.2em]">Grupo Müller</span>
              </div>
              <p className="mt-3 text-sm leading-6 text-slate-600">
                Mais de 50 mil clientes atendidos com ofertas reais, proximidade e economia no dia a dia.
              </p>
            </div>
            <div className="rounded-3xl border border-slate-200/70 bg-white/80 p-5 text-left shadow-lg shadow-slate-200/10 backdrop-blur-xl">
              <div className="flex items-center gap-3 text-slate-700">
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-[#ff9b88]/10 text-[#ff6f4d]">
                  <Sparkles className="h-5 w-5" />
                </span>
                <span className="text-sm font-semibold uppercase tracking-[0.2em]">Cresça com a gente</span>
              </div>
              <p className="mt-3 text-sm leading-6 text-slate-600">
                Estamos sempre em busca de pessoas comprometidas, com vontade de aprender e crescer junto com o time.
              </p>
            </div>
            <div className="rounded-3xl border border-slate-200/70 bg-white/80 p-5 text-left shadow-lg shadow-slate-200/10 backdrop-blur-xl">
              <div className="flex items-center gap-3 text-slate-700">
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-[#8eb6ff]/10 text-[#3f70f3]">
                  <Briefcase className="h-5 w-5" />
                </span>
                <span className="text-sm font-semibold uppercase tracking-[0.2em]">Nosso jeito de ser</span>
              </div>
              <p className="mt-3 text-sm leading-6 text-slate-600">
                Valorizamos organização, atitude, foco em resultado e espírito de dono em tudo que fazemos.
              </p>
            </div>
          </div>
        </div>
      </motion.main>
    </>
  );
};

export default VagasPage;
