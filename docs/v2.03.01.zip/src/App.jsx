
import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import ScrollToTop from '@/components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import CardRequestForm from '@/components/CardRequestForm';
import LoginPage from '@/pages/LoginPage';
import OperatorDashboard from '@/pages/OperatorDashboard';
import WebhookConfigPage from '@/pages/WebhookConfigPage';
import ImageConfigPage from '@/pages/ImageConfigPage';
import VagasPage from '@/pages/VagasPage';

function App() {
  return (
    <Router>
      <AuthProvider>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<CardRequestForm />} />
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/operator-dashboard"
            element={
              <ProtectedRoute>
                <OperatorDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/webhook-config"
            element={
              <ProtectedRoute>
                <WebhookConfigPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/config"
            element={
              <ProtectedRoute>
                <WebhookConfigPage /> 
              </ProtectedRoute>
            }
          />
          <Route
            path="/image-config"
            element={
              <ProtectedRoute>
                <ImageConfigPage />
              </ProtectedRoute>
            }
          />
          <Route path="/vagas" element={<VagasPage />} />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;
