
import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getSession = async () => {
      try {
        const { data, error } = await supabase.auth.getSession();
        
        if (error) throw error;

        const session = data?.session;
        
        if (session?.user) {
          const isOperator = session.user.user_metadata?.role === 'operator';
          setCurrentUser(isOperator ? session.user : null);
          
          if (!isOperator && session.user) {
            await supabase.auth.signOut();
            toast({
              variant: "destructive",
              title: "Acesso negado",
              description: "Apenas operadores podem acessar o sistema.",
            });
          }
        } else {
          setCurrentUser(null);
        }
      } catch (error) {
        console.error("Auth session error:", error);
        toast({
          variant: "destructive",
          title: "Erro de autenticação",
          description: "Não foi possível verificar a sessão atual."
        });
      } finally {
        setLoading(false);
      }
    };

    getSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        try {
          if (session?.user) {
            const isOperator = session.user.user_metadata?.role === 'operator';
            setCurrentUser(isOperator ? session.user : null);
            
            if (!isOperator && session.user) {
              await supabase.auth.signOut();
              toast({
                variant: "destructive",
                title: "Acesso negado",
                description: "Apenas operadores podem acessar o sistema.",
              });
            }
          } else {
            setCurrentUser(null);
          }
        } catch (error) {
          console.error("Auth state change error:", error);
        } finally {
          setLoading(false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, [toast]);

  const login = useCallback(async (email, password) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      const isOperator = data.user?.user_metadata?.role === 'operator';
      
      if (!isOperator) {
        await supabase.auth.signOut();
        toast({
          variant: "destructive",
          title: "Acesso negado",
          description: "Apenas operadores podem acessar o sistema.",
        });
        return { error: new Error('Acesso negado') };
      }

      return { data, error: null };
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao fazer login",
        description: error.message || "Algo deu errado",
      });
      return { error };
    }
  }, [toast]);

  const logout = useCallback(async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      setCurrentUser(null);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao fazer logout",
        description: error.message || "Algo deu errado",
      });
    }
  }, [toast]);

  return (
    <AuthContext.Provider value={{ currentUser, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
